#!/bin/bash
python ./src/Test2-RESTful.py
