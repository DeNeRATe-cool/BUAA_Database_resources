#!/bin/bash
python ./src/Test1-ORM.py
